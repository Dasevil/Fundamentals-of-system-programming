This program was written for the discipline **"Fundamentals of Systems Programming"**.

The program searches through the pattern in the files recursively. My version in this paper is the *ninth*.

##***Variant 9***